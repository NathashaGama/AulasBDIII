const database = 'BDAula1';
const collection = 'LIVRARIA';
use(database);
db.createCollection(collection)

// seleciona os dados de todos os arquivos sem criterios
//db['LIVRARIA'].find();

//seleciona arquivos de dados com categorias definidas
//db['LIVRARIA'].find({"categoria":"Fantasia Heroica"});

//seleciona arquivos de dados com categorias definidas e ocultando certos campos
db['LIVRARIA'].find({"categoria":"Fantasia Heroica"},{"_id":0, "codigo":0, "descricao":0});