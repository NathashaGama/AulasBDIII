const database = 'BDAula1';
const collection = 'LIVRARIA';
use(database);
db.createCollection(collection)

//atualização de um arquivi do mongodb
/*
bd['LIVRARIA'].update(
    {codigo:'1'},
    {$set:{titulo:'Teste de alteracao de titulo'}}
);
*/
//excluir um arquivo no mongodb
db['LIVRARIA'].deleteOne({codigo: '1'});